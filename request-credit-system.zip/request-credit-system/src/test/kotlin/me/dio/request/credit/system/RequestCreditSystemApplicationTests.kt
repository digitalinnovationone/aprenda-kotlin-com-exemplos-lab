package me.dio.request.credit.system

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class RequestCreditSystemApplicationTests {

	@Test
	fun contextLoads() {
	}

}
